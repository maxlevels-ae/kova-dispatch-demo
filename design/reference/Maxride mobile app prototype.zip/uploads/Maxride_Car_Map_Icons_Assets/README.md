# Maxride — UI Vehicle & Map Assets

## Folder contents
- `vehicles/png/`: 8 transparent generic vehicle renders (`640x480`) plus compact 320x240 versions.
- `map/svg/`: 8 top-down, rotatable vehicle marker SVGs + 4 colored location pins.
- `map/png/`: ready-to-use map marker PNGs at standard/retina resolutions.
- `icons/svg/` and `icons/png/`: 32 original UI icons (saved places, booking, pickup, stop, delivery, phone, chat, wallet, etc.) at 48px and 96px PNG.
- `asset-manifest.json`: filename/category mapping. `asset-preview.jpg`: contact preview.

## Correct Uber category references (official source reviewed 2026-11-05)
- UberX: everyday rides. Uber Comfort: newer cars, extra room. Uber Black: premium. UberXL: large vehicle for up to six passengers. Uber Electric: **fully electric** (not a hybrid).
- Some markets offer Comfort Electric, and Uber has other offerings such as WAV, Pet, Share. The available options vary by city/country.
- In the U.S., Uber announced renaming Uber Green to Uber Electric on October 22, 2025. Do not hardcode Uber's regional brand taxonomy into Maxride.
- References: https://www.uber.com/us/en/ride/ride-options/ and https://www.uber.com/us/en/newsroom/uber-electric/.

## Maxride implementation rules
The existing backend only supports `economy`, `comfort`, `premium`, `xl`. Other render/icon folders are **optional visual assets** and must not be shown as selectable vehicle tiers until the backend pricing, driver eligibility, category filters, booking validation, and admin settings all support them. Never label a hybrid as zero-emission/electric.

## Quick usage
Copy `vehicles`, `map` and `icons` directories under `public/assets/`. For example `/assets/vehicles/png/economy_card.png` and `/assets/map/svg/economy_top.svg`.

In a rider vehicle-choice card, show the generic category PNG as a category illustration; once a driver is assigned, show the actual uploaded `vehicle.imageUrl` if present.

For MapLibre driver markers, use the per-category top-view SVG as an `<img>`, sized approximately 28x36 CSS px, with a CSS transform rotation based on **actual** GPS heading, if available. If heading is unavailable, keep it north-up or preserve the previous reliable heading. Do not present heading estimates as live GPS.

The icons are original, vendor-neutral and do not carry Uber branding. Transparent images are intended to sit on the existing warm white Maxride palette.
